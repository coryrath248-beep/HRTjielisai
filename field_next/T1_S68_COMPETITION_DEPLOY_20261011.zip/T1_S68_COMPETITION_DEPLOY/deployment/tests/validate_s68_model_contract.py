"""Offline S68 artifact check; does not import ROS or publish commands."""

from pathlib import Path
import hashlib
import importlib.util
import time

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
TASK = ROOT / "tasks" / "hrt_s68"
EXPECTED = "3cf424a07c0037572be1954d928201006f8634cf0f7c151b6ff2078b46ddacb7"

model = TASK / "models" / "model.pt"
assert hashlib.sha256(model.read_bytes()).hexdigest() == EXPECTED

spec = importlib.util.spec_from_file_location("s68_footroom", TASK / "footroom_debug.py")
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

shadow = module.FootRoomShadow(
    config_path=TASK / "models" / "train.yaml",
    model_path=model,
    expected_model_sha256=EXPECTED,
)
assert shadow.policy_dt == 0.02
assert len(shadow.action_names) == 21
assert len(module.JOINT_NAMES) == 23

result = shadow.step(
    stamp=time.monotonic(),
    q=shadow.default_q.copy(),
    dq=np.zeros(23, dtype=np.float32),
    rpy=np.zeros(3, dtype=np.float32),
    gyro=np.zeros(3, dtype=np.float32),
    command=np.zeros(3, dtype=np.float32),
    pose=None,
)
assert len(result["observation"]) == 80
assert len(result["action"]) == 21
assert len(result["targets_urdf_rad"]) == 23
assert np.all(np.isfinite(result["targets_urdf_rad"]))
print("S68 model contract PASS", EXPECTED)

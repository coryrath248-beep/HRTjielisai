#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_USER="${SUDO_USER:-$USER}"
RUN_HOME="$(getent passwd "$RUN_USER" | cut -d: -f6)"
INSTALL_ROOT="$RUN_HOME/t1_s62_competition"
STAGE="$RUN_HOME/.t1_s62_competition.new"
SERVICE=t1-s62-competition.service

if [[ -z "$RUN_HOME" || ! -d "$RUN_HOME" ]]; then
  echo "Cannot resolve the deployment user's home directory" >&2
  exit 1
fi

cd "$ROOT"
python3 deployment/tests/validate_s62_model_contract.py
python3 -m compileall -q booster_deploy tasks/hrt_s62 scripts

rm -rf "$STAGE"
mkdir -p "$STAGE"
tar \
  --exclude=.git --exclude=.venv --exclude=__pycache__ --exclude='*.pyc' \
  --exclude=runtime.log \
  -cf - . | tar -xf - -C "$STAGE"
chown -R "$RUN_USER":"$(id -gn "$RUN_USER")" "$STAGE"

source /opt/ros/humble/setup.bash
source /opt/booster/BoosterRos2Interface/install/setup.bash
(
  cd "$STAGE"
  python3 scripts/deploy.py --list | grep -q '^  hrt_s62'
)

if systemctl is-active --quiet t1-s46.service; then
  printf 't1-s46.service\n' > "$STAGE/deployment/previous_custom_service"
fi

sudo systemctl stop "$SERVICE" 2>/dev/null || true
sudo systemctl disable t1-s46.service 2>/dev/null || true
if [[ -d "$INSTALL_ROOT" ]]; then
  BACKUP="$RUN_HOME/t1_s62_competition.backup.$(date +%Y%m%d_%H%M%S)"
  mv "$INSTALL_ROOT" "$BACKUP"
  echo "Previous S62 install saved at $BACKUP"
fi
mv "$STAGE" "$INSTALL_ROOT"

SERVICE_TMP="$(mktemp)"
sed \
  -e "s|@RUN_USER@|$RUN_USER|g" \
  -e "s|@INSTALL_ROOT@|$INSTALL_ROOT|g" \
  "$INSTALL_ROOT/deployment/t1-s62-competition.service" > "$SERVICE_TMP"
sudo install -m 0644 "$SERVICE_TMP" "/etc/systemd/system/$SERVICE"
rm -f "$SERVICE_TMP"
sudo systemctl daemon-reload
sudo systemctl enable --now "$SERVICE"
sudo systemctl --no-pager --full status "$SERVICE" | sed -n '1,12p'

echo
echo "S62 is installed. Put the robot in official Prepare, then press X once."
echo "X: policy zero stance  | sticks: walk/turn  | Y: right arm  | B: Prepare"

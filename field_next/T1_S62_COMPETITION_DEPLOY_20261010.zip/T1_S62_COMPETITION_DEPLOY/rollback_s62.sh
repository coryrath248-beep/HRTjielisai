#!/usr/bin/env bash
set -euo pipefail

RUN_USER="${SUDO_USER:-$USER}"
RUN_HOME="$(getent passwd "$RUN_USER" | cut -d: -f6)"
INSTALL_ROOT="$RUN_HOME/t1_s62_competition"

sudo systemctl disable --now t1-s62-competition.service 2>/dev/null || true
if [[ -f "$INSTALL_ROOT/deployment/previous_custom_service" ]]; then
  PREVIOUS="$(cat "$INSTALL_ROOT/deployment/previous_custom_service")"
  sudo systemctl enable --now "$PREVIOUS"
  echo "Restored $PREVIOUS"
else
  echo "S62 controller stopped. Official Booster services were not changed."
fi

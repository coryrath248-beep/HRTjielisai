"""Offline S62 artifact check; does not import ROS or publish commands."""

from pathlib import Path
import hashlib
import importlib.util
import time

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
TASK = ROOT / "tasks" / "hrt_s62"
EXPECTED = "6cf343cd70a59156ee1e25655754acda0a067b62907b7c1b211e3763fd8f066f"

model = TASK / "models" / "model.pt"
assert hashlib.sha256(model.read_bytes()).hexdigest() == EXPECTED

spec = importlib.util.spec_from_file_location("s62_footroom", TASK / "footroom_debug.py")
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)

shadow = module.FootRoomShadow(
    config_path=TASK / "models" / "train.yaml",
    model_path=model,
    expected_model_sha256=EXPECTED,
)
assert shadow.policy_dt == 0.02
assert len(shadow.action_names) == 21
assert len(module.JOINT_NAMES) == 23

result = shadow.step(
    stamp=time.monotonic(),
    q=shadow.default_q.copy(),
    dq=np.zeros(23, dtype=np.float32),
    rpy=np.zeros(3, dtype=np.float32),
    gyro=np.zeros(3, dtype=np.float32),
    command=np.zeros(3, dtype=np.float32),
    pose=None,
)
assert len(result["observation"]) == 80
assert len(result["action"]) == 21
assert len(result["targets_urdf_rad"]) == 23
assert np.all(np.isfinite(result["targets_urdf_rad"]))
print("S62 model contract PASS", EXPECTED)

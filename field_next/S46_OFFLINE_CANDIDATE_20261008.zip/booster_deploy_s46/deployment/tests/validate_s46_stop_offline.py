import time
import numpy as np
from booster_deploy.controllers.base_controller import BoosterRobot, VelocityCommand
from tasks.hrt_s46 import S46ControllerCfg, S46Policy
cfg = S46ControllerCfg()
dtype = np.dtype([('joint_pos', float, (23,)), ('joint_vel', float, (23,)), ('feedback_torque', float, (23,)), ('root_rpy_w', float, (3,)), ('root_ang_vel_b', float, (3,)), ('low_state_mono', float), ('odom_pose', float, (3,)), ('odom_mono', float)])
state = np.zeros(1, dtype=dtype)
class Buffer:
    def read(self): return state
class Portal:
    synced_state = Buffer()
class Controller: pass
c = Controller()
c.cfg = cfg
c.robot = BoosterRobot(cfg.robot)
c.vel_command = VelocityCommand(cfg.vel_command)
c.portal = Portal()
p = S46Policy(cfg.policy, c)
p.reset()
state[0]['joint_pos'][:] = p.shadow.default_q
state[0]['low_state_mono'] = time.monotonic()
state[0]['odom_mono'] = time.monotonic()
a = p.inference()
assert a.shape == (23,) and np.allclose(a.numpy(), state[0]['joint_pos'])
p.start_time -= 1.5
p.motion_mix = 1.0
p.filtered_command[0] = 0.2
p.last_infer_time = time.monotonic() - 0.02
c.vel_command.lin_vel_x = 0.5
state[0]['low_state_mono'] = time.monotonic()
state[0]['odom_mono'] = time.monotonic()
p.shadow.last_time = time.monotonic() - 0.02 if p.shadow.last_time is not None else None
b = p.inference()
assert b.shape == (23,) and np.all(np.isfinite(b.numpy()))
expected_gait_targets = p.shadow.default_q.copy()
expected_gait_targets[p.shadow.action_indices] += (
    p.shadow.action_scales * p.shadow.last_action
)
assert np.allclose(b.numpy(), expected_gait_targets, atol=1e-5), (
    'full gait must publish the exact trained actor targets'
)
assert abs(float(c.robot.joint_stiffness[11]) - 200.0) < 1e-4
assert abs(float(c.robot.joint_stiffness[14]) - 200.0) < 1e-4
assert abs(float(c.robot.joint_stiffness[15]) - 50.0) < 1e-4
c.vel_command.lin_vel_x = 0.0
p.filtered_command[0] = 1.6
p.last_infer_time = time.monotonic() - 0.02
state[0]['low_state_mono'] = time.monotonic()
state[0]['odom_mono'] = time.monotonic()
p.inference()
assert 1.57 < float(p.filtered_command[0]) < 1.6
assert p.motion_mix == 1.0
p.filtered_command[0] = 0.06
p.measured_vx = 0.5
p.last_infer_time = time.monotonic() - 0.02
state[0]['low_state_mono'] = time.monotonic()
state[0]['odom_mono'] = time.monotonic()
state[0]['root_ang_vel_b'][1] = 0.9
p.inference()
assert p.motion_mix < 1.0, 'zero-command gait must leave gait mode even with oscillating pitch rate and frozen odometry'
p.filtered_command[0] = 0.0
p.measured_vx = 0.0
p.last_infer_time = time.monotonic() - 0.02
state[0]['low_state_mono'] = time.monotonic()
state[0]['odom_mono'] = time.monotonic()
p.inference()
assert p.motion_mix < 1.0
for _ in range(55):
    p.last_infer_time = time.monotonic() - 0.02
    state[0]['low_state_mono'] = time.monotonic()
    state[0]['odom_mono'] = time.monotonic()
    p.inference()
assert p.motion_mix == 0.0, 'zero-command gait must finish standing transition in bounded time'
assert abs(float(c.robot.joint_stiffness[11]) - 350.0) < 1e-4

# Exercise the real adapter for a full forward stick press and release. The
# first samples must ease in, the velocity command must stay monotone, and
# release must not produce another forward acceleration or a reverse step.
p.reset()
state[0]['joint_pos'][:] = p.shadow.default_q
def step_forward(target):
    c.vel_command.lin_vel_x = target
    p.last_infer_time = time.monotonic() - 0.02
    state[0]['low_state_mono'] = time.monotonic()
    state[0]['odom_mono'] = time.monotonic()
    p.inference()
    return float(p.filtered_command[0])

rise = [step_forward(1.6) for _ in range(220)]
assert 0.0 < rise[0] < 0.003
assert np.all(np.diff(rise) >= -1e-6)
assert rise[-1] > 1.5
fall = [step_forward(0.0) for _ in range(220)]
assert 0.0 < rise[-1] - fall[0] < 0.003
assert np.all(np.diff(fall) <= 1e-6)
assert 0.0 <= fall[-1] < 0.08
print('S46 offline on robot PASS', float(np.max(np.abs(b.numpy() - a.numpy()))))

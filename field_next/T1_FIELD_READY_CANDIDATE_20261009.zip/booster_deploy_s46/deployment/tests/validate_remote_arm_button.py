import sys
import threading
import types


# This is a dependency-free logic check for development machines.  The robot
# supplies evdev, ROS 2 and Booster message packages at runtime.
evdev = types.ModuleType("evdev")
evdev.ecodes = types.SimpleNamespace(
    BTN_X=0x133, BTN_A=0x130, BTN_B=0x131, BTN_Y=0x134,
    ABS_X=0, ABS_Y=1, ABS_Z=2, EV_ABS=3,
)
evdev.InputDevice = object
evdev.list_devices = lambda: []
sys.modules["evdev"] = evdev

rclpy = types.ModuleType("rclpy")
rclpy.ok = lambda: False
sys.modules["rclpy"] = rclpy
executors = types.ModuleType("rclpy.executors")
executors.SingleThreadedExecutor = object
sys.modules["rclpy.executors"] = executors
qos = types.ModuleType("rclpy.qos")
qos.QoSProfile = object
qos.ReliabilityPolicy = types.SimpleNamespace(BEST_EFFORT=0, RELIABLE=1)
sys.modules["rclpy.qos"] = qos
booster_msg = types.ModuleType("booster_interface.msg")
booster_msg.RemoteControllerState = object
sys.modules["booster_interface"] = types.ModuleType("booster_interface")
sys.modules["booster_interface.msg"] = booster_msg
sensor_msg = types.ModuleType("sensor_msgs.msg")
sensor_msg.Joy = object
sys.modules["sensor_msgs"] = types.ModuleType("sensor_msgs")
sys.modules["sensor_msgs.msg"] = sensor_msg
termios = types.ModuleType("termios")
termios.TCSADRAIN = 0
termios.tcgetattr = lambda _fd: None
termios.tcsetattr = lambda *_args: None
sys.modules["termios"] = termios
tty = types.ModuleType("tty")
tty.setcbreak = lambda _fd: None
sys.modules["tty"] = tty

from booster_deploy.utils.remote_control_service import JoystickConfig, RemoteControlService


class FakeJoystick:
    def __init__(self):
        self.keys = []

    def active_keys(self):
        return list(self.keys)


service = RemoteControlService.__new__(RemoteControlService)
service.config = JoystickConfig()
service._lock = threading.Lock()
service.joystick = FakeJoystick()
service._topic_arm_pose = False
service.keyboard_toggle_arm_pose = False
service._joystick_arm_down = False

assert not service.toggle_right_arm_pose()
service.joystick.keys = [evdev.ecodes.BTN_Y]
assert service.toggle_right_arm_pose()
assert not service.toggle_right_arm_pose(), "holding Y must not repeat the toggle"
service.joystick.keys = []
assert not service.toggle_right_arm_pose()
service.joystick.keys = [evdev.ecodes.BTN_Y]
assert service.toggle_right_arm_pose(), "a new Y press must remain reusable"

service.joystick.keys = []
service._topic_arm_pose = True
assert service.toggle_right_arm_pose()
assert not service.toggle_right_arm_pose(), "topic latch must be consumed once"
service.keyboard_toggle_arm_pose = True
assert service.toggle_right_arm_pose()

print("Independent right-arm button PASS")

import time

import numpy as np

from booster_deploy.controllers.stance_gate import zero_policy_stance_settled


now = time.monotonic()
action = {
    "stamp_mono": now - 0.01,
    "dof_target": np.zeros(23),
}
state = {
    "joint_pos": np.full(23, 0.03),
    "root_ang_vel_b": np.array([0.02, 0.03, 0.0]),
}
assert not zero_policy_stance_settled(action, state, now - 1.0, now)[0]
assert zero_policy_stance_settled(action, state, now - 1.6, now)[0]
action["stamp_mono"] = now - 0.2
assert not zero_policy_stance_settled(action, state, now - 1.6, now)[0]
action["stamp_mono"] = now - 0.01
state["joint_pos"][15] = 0.4
assert not zero_policy_stance_settled(action, state, now - 1.6, now)[0]
state["joint_pos"][15] = 0.03
state["root_ang_vel_b"][1] = 0.4
assert not zero_policy_stance_settled(action, state, now - 1.6, now)[0]
print("Zero-policy stance gate PASS")

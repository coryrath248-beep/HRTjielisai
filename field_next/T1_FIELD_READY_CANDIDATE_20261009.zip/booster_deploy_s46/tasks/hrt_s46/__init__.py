"""Full-body 80→21 policy adapter for Booster's official T1 controller."""

from __future__ import annotations

import math
import logging
from pathlib import Path
import time

import numpy as np
import torch

from booster_deploy.controllers.base_controller import BaseController, Policy
from booster_deploy.controllers.controller_cfg import (
    BoosterRobotControllerCfg,
    ControllerCfg,
    PolicyCfg,
    VelocityCommandCfg,
)
from booster_deploy.robots.t1 import T1_23DOF_CFG
from booster_deploy.utils.isaaclab.configclass import configclass
from booster_deploy.utils.registry import register_task
from tasks.locomotion.robots.t1 import T1WalkControllerCfg1

from .footroom_debug import FootRoomShadow, ManualPathReference, Pose2D


MODEL_SHA256 = "75e5772c27f61b857eb387dfaf2eaf50159c884ee3ad0513921afb2ca2f445f6"
TRANSITION_SECONDS = 1.5
MOTION_RAMP_SECONDS = 2.0
STOP_RAMP_SECONDS = 1.0
COMMAND_RATE_LIMIT = np.array([0.5, 0.8, 0.8], dtype=np.float32)
FORWARD_JERK_LIMIT = 1.5  # m/s^3; ramps the commanded acceleration at stick changes
FORWARD_TRACK_TIME = 0.35  # s; eases acceleration back to zero near the target
TURN_RATE_LIMIT = 0.4  # rad/s^2
TURN_JERK_LIMIT = 1.2  # rad/s^3
TURN_TRACK_TIME = 0.4  # s
MAX_LOW_STATE_AGE_SECONDS = 0.12
MAX_ODOMETRY_AGE_SECONDS = 0.30
logger = logging.getLogger("booster_deploy.s46")


class S46Policy(Policy):
    """Use the trained 80→21 adapter inside the official 23-joint controller."""

    def __init__(self, cfg: S46PolicyCfg, controller: BaseController):
        super().__init__(cfg, controller)
        self.cfg = cfg
        self.robot = controller.robot
        # The training PD gains are far below the T1 hardware walking gains.
        # Using them on the real robot made the hips and knees collapse as soon
        # as A enabled the policy. Keep the official gait controller's gains
        # for physical deployment; the actor's target positions are unchanged.
        walk_robot_cfg = T1WalkControllerCfg1().robot
        self.runtime_kp = torch.tensor(
            walk_robot_cfg.joint_stiffness, dtype=torch.float32
        )
        self.runtime_kd = torch.tensor(
            walk_robot_cfg.joint_damping, dtype=torch.float32
        )
        self.prepare_kp = torch.tensor(
            self.robot.cfg.prepare_state.stiffness, dtype=torch.float32
        )
        self.prepare_kd = torch.tensor(
            self.robot.cfg.prepare_state.damping, dtype=torch.float32
        )
        self.prepare_q = torch.tensor(
            self.robot.cfg.prepare_state.joint_pos, dtype=torch.float32
        )
        self.shadow: FootRoomShadow | None = None
        self.start_time: float | None = None
        self.start_q: torch.Tensor | None = None
        self.last_infer_time: float | None = None
        self.motion_mix = 0.0
        self.filtered_command = np.zeros(3, dtype=np.float32)
        self.forward_command_accel = 0.0
        self.turn_command_accel = 0.0
        self.turn_seen = False
        self.last_diag_time = 0.0
        self.last_pose = None
        self.last_pose_time = None
        self.measured_vx = 0.0

    def reset(self) -> None:
        task_dir = Path(self.task_path)
        self.shadow = FootRoomShadow(
            config_path=task_dir / self.cfg.config_path,
            model_path=task_dir / self.cfg.checkpoint_path,
            expected_model_sha256=self.cfg.expected_model_sha256,
        )
        if not math.isclose(self.shadow.policy_dt, self.controller.cfg.policy_dt):
            raise ValueError("S46 policy and controller time steps differ")
        self.start_time = None
        self.start_q = None
        self.last_infer_time = None
        self.motion_mix = 0.0
        self.filtered_command = np.zeros(3, dtype=np.float32)
        self.forward_command_accel = 0.0
        self.turn_command_accel = 0.0
        self.turn_seen = False
        self.last_diag_time = 0.0
        self.last_pose = None
        self.last_pose_time = None
        self.measured_vx = 0.0

    def inference(self) -> torch.Tensor:
        state = self.controller.portal.synced_state.read()[0]
        # The parent can write a newer state between two instructions. Read the
        # snapshot first, then date it, so fresh data never appears "future".
        now = time.monotonic()
        low_age = now - float(state["low_state_mono"])
        if not 0.0 <= low_age <= MAX_LOW_STATE_AGE_SECONDS:
            raise RuntimeError(f"low_state stale: {low_age:.3f} s")

        q = np.asarray(state["joint_pos"], dtype=np.float32)
        dq = np.asarray(state["joint_vel"], dtype=np.float32)
        rpy = np.asarray(state["root_rpy_w"], dtype=np.float32)
        gyro = np.asarray(state["root_ang_vel_b"], dtype=np.float32)
        if q.shape != (23,) or not np.all(np.isfinite(q)):
            raise RuntimeError("invalid 23-joint feedback")
        if not np.all(np.isfinite(dq)) or not np.all(np.isfinite(rpy)):
            raise RuntimeError("invalid velocity or attitude feedback")
        if abs(float(rpy[0])) > 0.55 or abs(float(rpy[1])) > 0.55:
            raise RuntimeError(
                "body attitude outside S46 operating range: "
                f"roll={rpy[0]:.3f} pitch={rpy[1]:.3f} "
                f"pitch_rate={gyro[1]:.3f} "
                f"vx={getattr(self.controller.vel_command, 'lin_vel_x', 0.0):.3f}"
            )

        if self.start_time is None:
            self.start_time = now
            if self.cfg.zero_policy_at_rest:
                # Direct policy preparation retains this exact command target
                # across the mode switch. Measured q can lag behind it.
                held = getattr(self.controller.portal, "motor_cmd", None)
                if held is None or len(held) != self.robot.num_joints:
                    raise RuntimeError("Direct policy preparation has no held joint target")
                held_q = np.asarray([motor.q for motor in held], dtype=np.float32)
                if not np.all(np.isfinite(held_q)):
                    raise RuntimeError("Direct policy preparation hold is not finite")
                self.start_q = torch.from_numpy(held_q)
            else:
                # Standing preparation has just published prepare_q as its
                # final target. Preserve that exact first command target.
                self.start_q = self.prepare_q.clone()
        assert self.start_q is not None and self.shadow is not None
        fraction = min(1.0, (now - self.start_time) / TRANSITION_SECONDS)
        blend = fraction * fraction * (3.0 - 2.0 * fraction)

        velocity = self.controller.vel_command
        if velocity is None:
            raise RuntimeError("S46 requires joystick velocity commands")
        requested_command = np.array(
            [velocity.lin_vel_x, velocity.lin_vel_y, velocity.ang_vel_yaw],
            dtype=np.float32,
        )
        dt = self.controller.cfg.policy_dt if self.last_infer_time is None else min(
            max(now - self.last_infer_time, 0.0), 0.05
        )
        self.last_infer_time = now
        odom_age = now - float(state["odom_mono"])
        pose = None
        if 0.0 <= odom_age <= MAX_ODOMETRY_AGE_SECONDS:
            x, y, theta = state["odom_pose"]
            pose = Pose2D(float(x), float(y), float(theta)).checked()
            if self.last_pose is not None and self.last_pose_time is not None:
                pose_dt = now - self.last_pose_time
                if 0.005 <= pose_dt <= 0.2:
                    dx = pose.x - self.last_pose.x
                    dy = pose.y - self.last_pose.y
                    raw_vx = (math.cos(pose.theta) * dx + math.sin(pose.theta) * dy) / pose_dt
                    if math.isfinite(raw_vx) and abs(raw_vx) < 4.0:
                        alpha = min(1.0, pose_dt / 0.2)
                        self.measured_vx += alpha * (raw_vx - self.measured_vx)
            self.last_pose = pose
            self.last_pose_time = now
        # Ease the forward acceleration in and out. A sudden stick release
        # must never keep accelerating the robot in the old direction.
        forward_error = float(requested_command[0] - self.filtered_command[0])
        if forward_error * self.forward_command_accel < 0.0:
            self.forward_command_accel = 0.0
        desired_accel = float(np.clip(
            forward_error / FORWARD_TRACK_TIME,
            -COMMAND_RATE_LIMIT[0], COMMAND_RATE_LIMIT[0],
        ))
        jerk_step = FORWARD_JERK_LIMIT * dt
        self.forward_command_accel += float(np.clip(
            desired_accel - self.forward_command_accel, -jerk_step, jerk_step
        ))
        forward_next = float(self.filtered_command[0]) + self.forward_command_accel * dt
        if forward_error == 0.0 or forward_error * (float(requested_command[0]) - forward_next) <= 0.0:
            forward_next = float(requested_command[0])
            self.forward_command_accel = 0.0
        self.filtered_command[0] = forward_next
        lateral_step = float(COMMAND_RATE_LIMIT[1]) * dt
        self.filtered_command[1] += float(np.clip(
            requested_command[1] - self.filtered_command[1],
            -lateral_step, lateral_step,
        ))
        turn_error = float(requested_command[2] - self.filtered_command[2])
        if turn_error * self.turn_command_accel < 0.0:
            self.turn_command_accel = 0.0
        desired_turn_accel = float(np.clip(
            turn_error / TURN_TRACK_TIME, -TURN_RATE_LIMIT, TURN_RATE_LIMIT,
        ))
        turn_jerk_step = TURN_JERK_LIMIT * dt
        self.turn_command_accel += float(np.clip(
            desired_turn_accel - self.turn_command_accel,
            -turn_jerk_step, turn_jerk_step,
        ))
        turn_next = float(self.filtered_command[2]) + self.turn_command_accel * dt
        if turn_error == 0.0 or turn_error * (float(requested_command[2]) - turn_next) <= 0.0:
            turn_next = float(requested_command[2])
            self.turn_command_accel = 0.0
        self.filtered_command[2] = turn_next
        if abs(turn_next) > 0.1:
            self.turn_seen = True
        if np.max(np.abs(self.filtered_command)) > 0.08:
            self.motion_mix = min(1.0, self.motion_mix + dt / MOTION_RAMP_SECONDS)
        else:
            # Custom-mode odometry stayed at zero during the ground walk. A
            # feedback-based stop gate therefore cannot establish true body
            # speed. Waiting for quiet pitch rate also deadlocked: the zero-
            # command policy kept moving the legs, preventing quiet posture.
            # After the command has ramped to zero, finish the pose handoff in
            # bounded time so the gait cannot continue indefinitely.
            stop_seconds = STOP_RAMP_SECONDS * (1.4 if self.turn_seen else 1.0)
            self.motion_mix = max(0.0, self.motion_mix - dt / stop_seconds)
            if self.motion_mix == 0.0:
                self.turn_seen = False
        # Keep walking while the velocity command decays. The old expression
        # requested_command * motion_mix dropped to zero on the first neutral
        # joystick sample, then blended the legs straight into standing pose.
        command = self.filtered_command.copy()

        straight = command[0] > 0.2 and abs(command[1]) < 0.05 and abs(command[2]) < 0.06
        if straight and pose is None:
            raise RuntimeError(f"odometry stale during straight walking: {odom_age:.3f} s")

        result = self.shadow.step(
            stamp=now,
            q=q,
            dq=dq,
            rpy=rpy,
            gyro=gyro,
            command=command,
            pose=pose,
        )
        policy_targets = torch.tensor(result["targets_urdf_rad"], dtype=torch.float32)
        if not torch.all(torch.isfinite(policy_targets)):
            raise RuntimeError("S46 target is not finite")
        # At full gait weight, use the actor's 23-joint targets unchanged.
        # The earlier ankle bias and narrow clip changed many walking steps.
        if not self.cfg.zero_policy_at_rest:
            policy_targets = torch.lerp(self.prepare_q, policy_targets, self.motion_mix)

        if now - self.last_diag_time >= 0.2:
            leg_idx = [11, 14, 15, 17, 20, 21]
            logger.info(
                "S46_DIAG pitch=%.3f roll=%.3f pitch_rate=%.3f yaw_rate=%.3f "
                "vx_req=%.3f vx_eff=%.3f odom_vx=%.3f yaw=%.3f mix=%.2f "
                "leg_q=%s leg_target=%s leg_dq=%s leg_tau=%s",
                float(rpy[1]), float(rpy[0]), float(gyro[1]), float(gyro[2]),
                float(requested_command[0]), float(command[0]), float(self.measured_vx),
                float(command[2]), float(self.motion_mix),
                np.round(q[leg_idx], 3).tolist(),
                np.round(policy_targets[leg_idx].numpy(), 3).tolist(),
                np.round(dq[leg_idx], 3).tolist(),
                np.round(np.asarray(state["feedback_torque"])[leg_idx], 2).tolist(),
            )
            self.last_diag_time = now

        gain_mix = blend if self.cfg.zero_policy_at_rest else blend * self.motion_mix
        self.robot.joint_stiffness = torch.lerp(self.prepare_kp, self.runtime_kp, gain_mix)
        self.robot.joint_damping = torch.lerp(self.prepare_kd, self.runtime_kd, gain_mix)
        return torch.lerp(self.start_q, policy_targets, blend)


@configclass
class S46PolicyCfg(PolicyCfg):
    constructor = S46Policy
    checkpoint_path: str = "models/model.pt"
    config_path: str = "models/train.yaml"
    expected_model_sha256: str = MODEL_SHA256
    zero_policy_at_rest: bool = True


@configclass
class S46ControllerCfg(ControllerCfg):
    policy_dt: float = 0.02
    # One X press enters Custom and starts this policy at zero command.  The
    # stance gate enables velocity only after the learned low stance settles.
    robot = T1_23DOF_CFG.replace(prepare_mode="policy")
    vel_command: VelocityCommandCfg = VelocityCommandCfg(
        vx_max=1.6,
        vx_forward_max=1.6,
        vx_backward_max=1.0,
        vy_max=1.0,
        vyaw_max=0.5,
    )
    policy: S46PolicyCfg = S46PolicyCfg()
    booster: BoosterRobotControllerCfg = BoosterRobotControllerCfg(
        exit_mode="prepare",
        smooth_exit=True,
        auto_prepare_on_stop=False,
        # The official SDK example raises the right arm forward by commanding
        # right shoulder pitch to -pi/2.  Y toggles this single-motor overlay,
        # and it is applied only after locomotion stops.
        right_arm_pose_joint_names=["right_shoulder_pitch_joint"],
        right_arm_pose_joint_targets=[-1.57],
        right_arm_pose_slew_rate_rad_s=0.9,
        right_arm_pose_only_at_rest=True,
        right_arm_pose_rest_speed_threshold=0.08,
    )


register_task("hrt_s46", S46ControllerCfg())

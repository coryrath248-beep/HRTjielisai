"""Read-only gate for enabling joystick motion after zero-command policy entry."""

import numpy as np


def zero_policy_stance_settled(action, state, first_action_at: float, now: float):
    """Return whether a fresh T1 action has tracked quietly for at least 1.5 s."""
    stamp = float(action["stamp_mono"])
    age = now - stamp
    if not (stamp > 0.0 and 0.0 <= age < 0.15 and now - first_action_at >= 1.5):
        return False, float("inf"), float("inf")
    actual = np.asarray(state["joint_pos"], dtype=np.float64)
    target = np.asarray(action["dof_target"], dtype=np.float64)
    gyro = np.asarray(state["root_ang_vel_b"], dtype=np.float64)
    if actual.shape != (23,) or target.shape != (23,) or gyro.shape != (3,):
        return False, float("inf"), float("inf")
    if not (np.all(np.isfinite(actual)) and np.all(np.isfinite(target)) and np.all(np.isfinite(gyro))):
        return False, float("inf"), float("inf")
    leg_error = float(np.max(np.abs(actual[11:] - target[11:])))
    tilt_rate = float(np.max(np.abs(gyro[:2])))
    return leg_error < 0.35 and tilt_rate < 0.35, leg_error, tilt_rate
